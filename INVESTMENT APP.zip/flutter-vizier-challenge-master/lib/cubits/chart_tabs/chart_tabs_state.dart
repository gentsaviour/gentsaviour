part of 'chart_tabs_cubit.dart';

@freezed
class ChartTabsState with _$ChartTabsState {
  const factory ChartTabsState.tab(ChartTab selectedTab) = _Tab;
}
