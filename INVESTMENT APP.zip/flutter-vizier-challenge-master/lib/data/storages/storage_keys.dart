abstract class StorageKeys {
  const StorageKeys._();

  static const String firstLaunch = 'key-first-launch';
  static const String accessToken = 'key-access-token';
}
