enum OfferSliderType {
  price,
  year,
  month,
}
