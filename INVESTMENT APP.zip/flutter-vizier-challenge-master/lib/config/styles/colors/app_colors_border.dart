part of 'app_colors.dart';

class _Border {
  const _Border();

  Color get success => AppColors.success100;
  Color get info => AppColors.info100;
  Color get error => AppColors.error300;
}
