part of 'app_theme.dart';

ThemeData get darkTheme {
  return lightTheme;
}
