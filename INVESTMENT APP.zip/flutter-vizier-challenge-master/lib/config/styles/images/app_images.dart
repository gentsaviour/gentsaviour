part 'svg_images.dart';

class AppImages {
  static const _SvgImages svg = _SvgImages();
}
