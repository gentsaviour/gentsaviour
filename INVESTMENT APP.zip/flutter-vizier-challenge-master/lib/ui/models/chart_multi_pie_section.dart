import 'package:vizier/ui/models/chart_multi_pie_item.dart';

class ChartMultiPieSection {
  final List<ChartMultiPieItem> items;

  const ChartMultiPieSection({
    required this.items,
  });
}
