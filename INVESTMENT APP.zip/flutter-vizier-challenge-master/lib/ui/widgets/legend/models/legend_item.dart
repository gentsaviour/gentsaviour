part of 'legend.dart';

class LegendItem {
  final Color color;
  final String label;

  const LegendItem({
    required this.color,
    required this.label,
  });
}
