import 'package:vizier/data/models/account/account_model.dart';

class FinancialBreakdownPageArguments {
  final AccountModel account;

  FinancialBreakdownPageArguments({
    required this.account,
  });
}
