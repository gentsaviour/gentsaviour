package com.example.vizier

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
